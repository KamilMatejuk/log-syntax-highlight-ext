DEFAULT_OPTIONS = {
    'date': '#07aa04',
    'plus': '#808080',
    'stage': '#ff0000',
    'pipeline': '#808080',
    'brackets': '#ff8800',
    'hidePipeline': false,
    'hidePlus': false,
    'hideAll': false,
};
